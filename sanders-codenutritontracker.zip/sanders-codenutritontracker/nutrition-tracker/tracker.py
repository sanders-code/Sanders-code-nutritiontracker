import csv
from datetime import datetime

# Step 1: Define a function to log a meal
def log_meal():
    print("\n--- Log a New Meal ---")
    meal = input("Meal name: ")
    calories = int(input("Calories: "))
    protein = float(input("Protein (g): "))
    carbs = float(input("Carbs (g): "))
    fats = float(input("Fats (g): "))
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Save to CSV
    with open("data.csv", mode="a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, meal, calories, protein, carbs, fats])
    print("✅ Meal logged successfully!")

# Step 2: Define a function to view logged meals
def view_meals():
    print("\n--- Meal History ---")
    try:
        with open("data.csv", mode="r") as file:
            reader = csv.reader(file)
            for row in reader:
                print(f"{row[0]} | {row[1]} | {row[2]} cal | P:{row[3]}g C:{row[4]}g F:{row[5]}g")
    except FileNotFoundError:
        print("No meals logged yet.")

# Step 3: Main menu loop
def main():
    while True:
        print("\nNutrition Tracker")
        print("1. Log a meal")
        print("2. View meals")
        print("3. Exit")
        choice = input("Choose an option (1-3): ")

        if choice == "1":
            log_meal()
        elif choice == "2":
            view_meals()
        elif choice == "3":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")

# Step 4: Run the program
if __name__ == "__main__":
    main()
